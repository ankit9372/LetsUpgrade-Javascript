var i = prompt(" Minutes: ")
console.log("seconds: ",i*60);